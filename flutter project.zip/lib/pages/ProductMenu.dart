import 'package:example/const.dart';
import 'package:flutter/material.dart';

class ProductMenu extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar : AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
      ),
    );
  }
}
