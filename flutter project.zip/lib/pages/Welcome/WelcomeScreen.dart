import 'package:example/const.dart';
import 'package:flutter/material.dart';

import 'Body.dart';

class WelcomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Body(),
    );
  }
}
