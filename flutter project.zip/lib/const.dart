import 'package:flutter/material.dart';

const textColor = Color.fromARGB(240, 83, 83, 83);
const textLight = Color.fromARGB(255, 160, 159, 159);
const constPaddin = 20.0;
